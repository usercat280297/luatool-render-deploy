-- 292120's Lua and Manifest Created by Morrenus
-- FINAL FANTASY XIII
-- Created: September 29, 2025 at 12:15:34 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 7
-- Total DLCs: 0
-- Shared Depots: 5

-- MAIN APPLICATION
addappid(292120) -- FINAL FANTASY XIII
-- MAIN APP DEPOTS
addappid(292121, 1, "80234db32af6ccde408480b0fdce3b9bc0ae476640909a3410943c2ddd62c608") -- FINAL FANTASY XIII Content JCK
setManifestid(292121, "8072044898226043193", 30738676601)
addappid(292122, 1, "661e081643c994179c8265ea189661608b85cd692da489d01396c7ca303c9033") -- FINAL FANTASY XIII Content NE
setManifestid(292122, "293622978458769043", 61851360699)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 242743889)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)